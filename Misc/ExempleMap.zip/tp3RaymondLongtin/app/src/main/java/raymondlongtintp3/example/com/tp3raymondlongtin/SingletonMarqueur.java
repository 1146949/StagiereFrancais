package raymondlongtintp3.example.com.tp3raymondlongtin;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import com.google.android.gms.maps.model.Marker;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import raymondlongtintp3.example.com.tp3raymondlongtin.database.MarqueurBaseHelper;
import raymondlongtintp3.example.com.tp3raymondlongtin.database.MarqueurCursorWrapper;
import raymondlongtintp3.example.com.tp3raymondlongtin.database.MarqueurDbSchema.MarqueurTable;
import raymondlongtintp3.example.com.tp3raymondlongtin.database.MarqueurDbSchema.MarqueurTable.Colonnes;


/**
 * Class singleton qui donne access aux donnes de la base de donnee
 */
public class SingletonMarqueur {
    private static SingletonMarqueur m_singleton; // seule instance de la classe, suit le pattern Singleton
    private static SQLiteDatabase m_database; // base de données SQLite (assez explicite)
    // ce HashMap sert à relier le ID du marqueur de Google à nos informations de la base de données :
    // les String sont en fait l'id des marqueurs de google (type de retour de la méthode getId()) du Marker
    // ceci permet de faire une liaison avec notre identifiant et celui du Marker créé par google
    // sans menacer l'intégrité en n'utilisant que l'id des Marker. Ceci nous permettra en outre
    // de modifier aisément l'objet de notre base de données en fonction des objets gérés par Google.
    private static HashMap<String, UUID> m_listeIdMarqueurs;

    /**
     * Constructeur de la classe, ne doit être appelé qu'une seule fois
     *
     * @param p_context contexte d'appel du constructeur (Context)
     */
    private SingletonMarqueur(Context p_context) {
        m_database = new MarqueurBaseHelper(p_context.getApplicationContext()).getWritableDatabase();
    }

    /**
     * Acesseur de l'instance, créée l'instance la première fois.
     *
     * @param p_context contexte d'appel, n'est utile que pour accéder au contexte suppérieur (Context)
     * @return "référence" vers l'unique instance de la classe (SingletonMarqueur)
     */
    public static SingletonMarqueur get(Context p_context) {
        if (m_singleton == null) {
            m_singleton = new SingletonMarqueur(p_context);
            m_listeIdMarqueurs = new HashMap<>();   // types du HashMap inférés par la variable m_listeIdMarqueurs
        }

        return m_singleton;
    }

    /**
     * Va chercher les valeurs du marqueur (ID et nom) et les insère dans la base de données
     * Lui ajoute un identifiant unique (UUID)
     *
     * @param p_marqueur Marqueur dont on veut les informations
     * @param p_id identifiant unique de la base de données
     * @return valeures du marqueur sous un format de base de données
     */
    private static ContentValues getContentValues(Marker p_marqueur, UUID p_id) {
        ContentValues values = new ContentValues(); // créée un "récipient" à valeur

        values.put(Colonnes.ID, p_id.toString());
        values.put(Colonnes.NOM, p_marqueur.getTitle());
        values.put(Colonnes.DESCRIPTION, p_marqueur.getSnippet());
        values.put(Colonnes.LATITUDE, p_marqueur.getPosition().latitude);
        values.put(Colonnes.LONGITUDE, p_marqueur.getPosition().longitude);

        return values;
    }

    /**
     * exécute une requête sur la base de données
     *
     * @param whereClause clause "where" pour filtrer les résultats "à l'entrée" (String)
     * @param whereArgs   arguments de la clause where, données servant à filtrer (String[])
     * @return un curseur encapsulé qui "pointe" sur la/les donnée(s) trouvées (MarqueurCursorWrapper)
     */
    private MarqueurCursorWrapper queryMarqueur(String whereClause, String[] whereArgs) {
        Cursor cursor = m_database.query(
                MarqueurTable.NAME,
                null, // Columns - null selects all columns
                whereClause,
                whereArgs,
                null, // groupBy
                null, // having
                null  // orderBy
        );

        // retourne un curseur encapsulé par MarqueurCursorWrapper (qui pointe sur le(s) élément(s) sélectionné(s))
        return new MarqueurCursorWrapper(cursor);
    }

    /**
     * Donne le nombre d'entrées dans la base de données
     * @return nombre de marqueurs dans la base de données
     */
    public int getNbMarqueurs()
    {
        return m_listeIdMarqueurs.size();
    }

    /**
     * Ajoute un Marqueur dans la base de données en faisant un "insert"
     *
     * @param p_marqueur Marqueur à ajouter (Marker)
     */
    public void addMarqueur(Marker p_marqueur) {
        // va chercher les valeurs du marqueur pour pouvoir les mettres dans la base de données
        ContentValues values = getContentValues(p_marqueur, UUID.randomUUID());

        // insère les valeurs dans la table InfoMarqueurTable.NAME
        m_database.insert(MarqueurTable.NAME, null, values);
        m_listeIdMarqueurs.put(p_marqueur.getId(), UUID.fromString((String) values.get(Colonnes.ID)));
    }


    /**
     * Ajoute un marqueur au HashMap (notre liste de liens entre la base de données et la GoogleMap)
     * @param p_idMarqueurHashMap identifiant du Marqueur dans la GoogleMap
     * @param p_idMarqueurBD identifiant du Marqueur dans la BD
     */
    public void addMarqueur(String p_idMarqueurHashMap, UUID p_idMarqueurBD)
    {
        m_listeIdMarqueurs.put(p_idMarqueurHashMap, p_idMarqueurBD);
    }

    /**
     * met à jour un Marqueur de la base de données (ne modifie pas l'id de celui-ci)
     *
     * @param p_marqueur Marqueur modifié, son identifiant doit être le bon et exister (Marker)
     */
    public void updateMarqueur(Marker p_marqueur) {
        // va chercher les valeurs du marqueur pour pouvoir remplacer les informations dans la base de données
        // note : on va chercher l'id du marqueur de la base de données (UUID) avec celui de la Google Map (String)
        // on se sert ensuite de ce UUID pour mettre l'information à jour dans la base de données
        ContentValues values = getContentValues(p_marqueur, m_listeIdMarqueurs.get(p_marqueur.getId()));
        String uuidString = values.get(Colonnes.ID).toString();

        // fait une requête update dans la base de données, sur la table InfoMarqueurTable.NAME
        // et met à jour les éléments ayant le même ID (en principe, un et un seul)
        m_database.update(MarqueurTable.NAME, values,
                Colonnes.ID + " = ?",
                new String[]{uuidString});
    }

    /**
     * Retire un marqueur par son UUID de la BD
     * @param p_idMarqueur vrai si le retrait a fonctionné
     */
    private boolean deleteMarqueurBD(UUID p_idMarqueur)
    {
        return m_database.delete(MarqueurTable.NAME, Colonnes.ID + "=?",
                // mettre le UUID en string empèche les erreures du genre "unrecognized token 416d"
                // (la base de données n'aime pas les tirets présents dans )
                new String[]{p_idMarqueur.toString()}) != 0;
    }

    /**
     * Retire le marqueur de la BD et de la liste de liens (HashMap) entre la GoogleMap et la BD
     * @param p_idMarqueurGoogleMap l'id du marqueur
     * @return Vrai si le retrait de la liste de liens ET de la BD a fonctionné
     */
    public boolean deleteMarqueur(String p_idMarqueurGoogleMap) {
        UUID idMarqueurBD = m_listeIdMarqueurs.remove(p_idMarqueurGoogleMap);

        // si l'id est null (le premier remove n'a pas fonctionné)
        // on renvoie faux,
        // sinon on renvoie le résultat du retrait dans la BD
        return (idMarqueurBD != null && deleteMarqueurBD(idMarqueurBD));
    }

    /**
     * Acesseur de la liste de marqueurs dans la base de données
     *
     * @return la liste de marqueurs
     */
    public List<Marqueur> getListeMarqueurs() {
        List<Marqueur> marqueurs = new ArrayList<>(); // créée un ArrayList (dérive de List)

        // créée un curseur Encapsulé à partir d'une requête sur toute la table (SELECT * FROM ...)
        // ... étant InfoMarqueurTable.NAME
        MarqueurCursorWrapper cursor = queryMarqueur(null, null);

        // essaie de bouger le curseur jusqu'à ce qu'il atteigne la fin
        try {
            // déplace le curseur au début des résultats de la requête
            cursor.moveToFirst();

            // tant que le curseur n'a pas atteint la fin
            while (!cursor.isAfterLast()) {
                marqueurs.add(cursor.getMarqueur()); // on ajoute le marqueur pointé par le curseur à la liste
                cursor.moveToNext(); // bouge le curseur vers le prochain marqueur (ses informations)
            }
        }
        // si il y a une erreur quelquonque, on la laisse remonter après avoir fermé le curseur
        finally {
            cursor.close();
        }

        // si tout s'est bien déroulé, on retourne la liste d'informations sur des marqueurs
        return marqueurs;
    }
}