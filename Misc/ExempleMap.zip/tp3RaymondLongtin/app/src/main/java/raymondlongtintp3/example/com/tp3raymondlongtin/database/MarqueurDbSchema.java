package raymondlongtintp3.example.com.tp3raymondlongtin.database;

/**
 * classe qui représente le schéma de la base de données, fait partie de la couche modèle du MVC
 */
public class MarqueurDbSchema {
    /**
     * classe qui représente une table d'une base de données (relationnelle ou autre)
     */
    public static final class MarqueurTable {
        public static final String NAME = "Marqueur";

        /**
         * Représente les colones du tableau et leur contenu (identifiées par les String à l'intérieur)
         */
        public static final class Colonnes {
            public static final String ID = "uuid"; // colonne qui identifie un objet "Element" unique, cette valeur ne peut apparaître plus d'une fois
            public static final String NOM = "nom"; // colonne qui indique le nom d'un Element
            public static final String DESCRIPTION = "description"; // colonne qui indique le nom d'un Element
            public static final String LATITUDE = "latitude"; // colonne qui indique le nom d'un Element
            public static final String LONGITUDE = "longtitude"; // colonne qui indique le nom d'un Element

        } //class Colonnes
    } // class ElementTable
}  // class ElementDbSchema
