package raymondlongtintp3.example.com.tp3raymondlongtin;

import android.app.Dialog;
import android.support.v4.app.FragmentActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends FragmentActivity implements GoogleMap.OnMapClickListener {

    public enum Mode {
        Aucun, Ajout, Information, Modification
    }

    private Mode m_mode = Mode.Aucun;
    private GoogleMap m_map; // Might be null if Google Play services APK is not available.

    private Marker m_marqueurCourant; // marqueur sélectionné par l'utilisateur

    // la position dans la variable qui suit est celle du marqueur courant avant les changements
    // alors que le nom et la description sont ceux qui ont changé.
    // C'est le cas parce que la position est mise à jour automatiquement par la GoogleMap (on doit alors la conserver dans une variable)
    // mais on ne veut pas modifier directement le nom et la description dans le marqueur en cas de crash ou autre...
    private LatLng m_position;  // position enregistrée du marqueur avant la modification
    private String m_nom, m_description;    // nom et description changés lors de la modification
    private boolean m_marqueurEstModifie = false; // indique si le marqueur courant a été modifié

    // boutons du mode ajout
    private Button m_boutonAjouter;

    // boutons du mode information
    private Button m_boutonModifier;
    private Button m_boutonSupprimer;

    // boutons du mode modification
    private Button m_boutonSauvegarder;
    private Button m_boutonDetail;

    // bouton utile à plusieurs modes
    private Button m_boutonAnnuler;

    // zones de texte pour l'affichage d'information dans la zone d'information
    private TextView m_textInformation1, m_textInformation2;
    private SingletonMarqueur m_singleton;


    /**
     * Méthode appelée lors de la création de l'activité
     *
     * @param savedInstanceState informations sauvegardées lors de la recréation de l'activité (inutile ici)
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_carte);

        m_singleton = SingletonMarqueur.get(getApplicationContext());
        setUpMapIfNeeded();

        AffecterControles();
        ChangerMode(Mode.Aucun);
    }

    /**
     * Remplis la GoogleMap avec les marqueurs de la base de données
     */
    private void ChargerMap() {
        for (Marqueur marqueur : m_singleton.getListeMarqueurs()) {
            Marker marqueurMap = m_map.addMarker(new MarkerOptions()
                    .title(marqueur.getNom())
                    .snippet(marqueur.getDescription())
                    .position(marqueur.getPosition()));
            // cette ligne fait le lien entre la base de données et la map de Google.
            m_singleton.addMarqueur(marqueurMap.getId(), marqueur.getID());
        }
    }

    /**
     * Affecte les contrôles dans les varaibles membre, doit se faire avant d'opérer sur les boutons
     * ou sur les zones de texte
     */
    private void AffecterControles() {
        m_textInformation1 = (TextView) findViewById(R.id.textView_zone_information1);
        m_textInformation2 = (TextView) findViewById(R.id.textView_zone_information2);

        m_boutonAjouter = (Button) findViewById(R.id.carte_boutonAjout);
        m_boutonModifier = (Button) findViewById(R.id.carte_boutonModifier);
        m_boutonSupprimer = (Button) findViewById(R.id.carte_boutonSupprimer);
        m_boutonSauvegarder = (Button) findViewById(R.id.carte_boutonSauvegarder);
        m_boutonAnnuler = (Button) findViewById(R.id.carte_boutonAnnuler);
        m_boutonDetail = (Button) findViewById(R.id.carte_boutonDetail);

        CreerListenersBoutons();
    }

    /**
     * Créée les oncLickListener sur tous les boutons...
     * fait appel aux méthodes de création des boutons respectifs
     */
    private void CreerListenersBoutons() {
        CreerBoutonAjouter();
        CreerBoutonModifier();
        CreerBoutonSupprimer();
        CreerBoutonSauvegarder();
        CreerBoutonAnnuler();
        CreerBoutonDetail();
    }

    /**
     * Créée le onClickListener du bouton Ajouter
     */
    private void CreerBoutonAjouter() {
        m_boutonAjouter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangerMode(Mode.Ajout);
            }
        });
    }

    /**
     * Créée le onClickListener du bouton Modifier
     */
    private void CreerBoutonModifier() {
        m_boutonModifier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                m_nom = m_marqueurCourant.getTitle();
                m_description = m_marqueurCourant.getSnippet();
                // on sauvegarde la position du marqueur courant en recréant un LatLng pour éviter les références
                m_position = new LatLng(m_marqueurCourant.getPosition().latitude,
                        m_marqueurCourant.getPosition().longitude);
                ChangerMode(Mode.Modification);
            }
        });
    }

    /**
     * Créée le onClickListener du bouton Supprimer
     */
    private void CreerBoutonSupprimer() {
        m_boutonSupprimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // https://developers.google.com/android/reference/com/google/android/gms/maps/model/Marker.html#remove()
                // ici, le marqueur a un "undefined behaviour" si on fait .remove(), alors on sauvegarde temporairement son ID
                String idMarqueur = m_marqueurCourant.getId();
                m_marqueurCourant.remove();
                if (!m_singleton.deleteMarqueur(idMarqueur))
                    Toast.makeText(getBaseContext(), R.string.bd_delete_erreur, Toast.LENGTH_SHORT).show();
                ChangerMode(Mode.Aucun);
            }
        });
    }

    /**
     * Créée le onClickListener du bouton Detail
     */
    private void CreerBoutonDetail() {
        m_boutonDetail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialogueModification();
            }
        });
    }

    /**
     * Créée le onClickListener du bouton Sauvegarder
     */
    private void CreerBoutonSauvegarder() {
        m_boutonSauvegarder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (m_marqueurEstModifie) {
                    m_marqueurCourant.setTitle(m_nom);
                    m_marqueurCourant.setSnippet(m_description);
                    m_singleton.updateMarqueur(m_marqueurCourant);
                    // remet à jour l'affichage
                    m_marqueurCourant.hideInfoWindow();
                    m_marqueurCourant.showInfoWindow();
                }

                ChangerMode(Mode.Information);
            }
        });
    }

    /**
     * Créée le onClickListener du bouton Annuler
     */
    private void CreerBoutonAnnuler() {
        m_boutonAnnuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (m_mode == Mode.Ajout)
                    ChangerMode(Mode.Aucun);
                else if (m_mode == Mode.Information)
                    ChangerMode(Mode.Aucun);
                else if (m_mode == Mode.Modification) {
                    m_marqueurCourant.setPosition(m_position);
                    ChangerMode(Mode.Information);
                }
            }
        });
    }

    /**
     * créée les listeners sur les marqueurs de la GoogleMap
     */
    private void CreerListenerMarqueur() {
        m_map.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                m_marqueurCourant = marker;
                ChangerMode(Mode.Information);

                return false;
            }
        });

        // ce listener met automatiquement la position du marqueur à jour
        m_map.setOnMarkerDragListener(new GoogleMap.OnMarkerDragListener() {
            @Override
            public void onMarkerDragStart(Marker marker) {

            }

            @Override
            public void onMarkerDrag(Marker marker) {

            }

            @Override
            public void onMarkerDragEnd(Marker marker) {

            }
        });
    }

    /**
     * Change le mode par celui donné et l'affichage par rapport au nouveau mode
     *
     * @param p_mode Nouveau mode
     */
    private void ChangerMode(Mode p_mode) {
        m_mode = p_mode;

        switch (m_mode) {
            case Ajout:
                ChangerAffichageModeAjout();
                break;
            case Modification:
                ChangerAffichageModeModification();
                break;
            case Information:
                ChangerAffichageModeInformation();
                break;
            default:    // Aucun
                ChangerAffichageAucunMode();
                break;
        }
    }

    /**
     * Change l'affichage des contrôles pour convenir au mode Ajout
     */
    private void ChangerAffichageModeAjout() {
        m_textInformation1.setText(R.string.fragment_carte_TextAjoutEndroit);
        m_textInformation2.setText("");
        m_boutonAjouter.setVisibility(View.GONE);
        m_boutonModifier.setVisibility(View.GONE);
        m_boutonSupprimer.setVisibility(View.GONE);
        m_boutonAnnuler.setVisibility(View.VISIBLE);
        m_map.setOnMapClickListener(this);  // this réfère à MapsActivity
    }

    /**
     * Change l'affichage des contrôles pour convenir au mode Modification
     */
    private void ChangerAffichageModeModification() {
        // on ne change pas isDraggable() partout, car Modification et Information sont les deux
        // seuls chemins possibles. C'est aussi le cas des autres contrôles
        m_boutonModifier.setVisibility(View.GONE);
        m_boutonSupprimer.setVisibility(View.GONE);
        m_boutonSauvegarder.setVisibility(View.VISIBLE);
        m_boutonDetail.setVisibility(View.VISIBLE);
        m_boutonAnnuler.setVisibility(View.VISIBLE);
        m_marqueurCourant.setDraggable(true);
    }

    /**
     * Change l'affichage des contrôles pour convenir au mode Information
     */
    private void ChangerAffichageModeInformation() {
        m_marqueurCourant.setDraggable(false);
        m_textInformation1.setText(m_marqueurCourant.getTitle());
        m_textInformation2.setText(m_marqueurCourant.getSnippet());
        m_boutonAjouter.setVisibility(View.GONE);
        m_boutonModifier.setVisibility(View.VISIBLE);
        m_boutonSupprimer.setVisibility(View.VISIBLE);
        m_boutonSauvegarder.setVisibility(View.GONE);
        m_boutonDetail.setVisibility(View.GONE);
        m_boutonAnnuler.setVisibility(View.VISIBLE);
    }

    /**
     * Change l'affichage des contrôles pour convenir au mode Aucun (Mode.Aucun)
     */
    private void ChangerAffichageAucunMode() {
        m_textInformation1.setText(R.string.fragment_carte_TextNbEndroit);
        m_textInformation2.setText(String.valueOf(m_singleton.getNbMarqueurs()));
        m_boutonAjouter.setVisibility(View.VISIBLE);
        m_boutonModifier.setVisibility(View.GONE);
        m_boutonSupprimer.setVisibility(View.GONE);
        m_boutonAnnuler.setVisibility(View.GONE);
        m_map.setOnMapClickListener(null);
    }

    /**
     * Méthode appelée lors du click sur la map
     *
     * @param point latitude et longitude de l'endroit cliqué sur la map
     */
    @Override
    public void onMapClick(LatLng point) {
        dialogueAjout(point);
    }

    /**
     * Donne un dialogue avec l'usager pour insérer un nouveau marqueur
     *
     * @param point position du marqueur s'il est enregistré
     */
    private void dialogueAjout(final LatLng point) {
        final Dialog dialog = new Dialog(MapsActivity.this);
        dialog.setTitle(R.string.dialogue_ajouterTitre);
        dialog.setContentView(R.layout.dialog_ajout_endroit);
        dialog.show();

        //dialogBuilder = new AlertDialog.Builder(this);
        final EditText nomEndroit = (EditText) dialog.findViewById(R.id.dialogEditTextNom);
        final EditText descriptionEndroit = (EditText) dialog.findViewById(R.id.dialogEditTextDescription);
        Button ok = (Button) dialog.findViewById(R.id.dialogButtonOk);
        Button annuler = (Button) dialog.findViewById(R.id.dialogButtonAnnuler);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                m_nom = nomEndroit.getText().toString();
                m_description = descriptionEndroit.getText().toString();

                if (!ValidationsMarqueur.ValiderMarqueur(v.getContext(), m_nom, m_description)) {
                    return;
                }

                Marker marqueur = m_map.addMarker(new MarkerOptions()
                        .position(new LatLng(point.latitude, point.longitude))
                        .title(m_nom)
                        .snippet(m_description));
                m_singleton.addMarqueur(marqueur);

                ChangerMode(Mode.Aucun);
                dialog.cancel();
            }
        });

        annuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangerMode(Mode.Aucun);
                dialog.cancel();
            }
        });
    }

    /**
     * Dialogue de modification du nom et de la description du marqueur sélectionné
     */
    private void dialogueModification() {
        final Dialog dialog = new Dialog(MapsActivity.this);
        dialog.setTitle(R.string.dialogue_ajouterTitre);
        dialog.setContentView(R.layout.dialog_ajout_endroit);
        dialog.show();

        //dialogBuilder = new AlertDialog.Builder(this);
        final EditText nomEndroit = (EditText) dialog.findViewById(R.id.dialogEditTextNom);
        final EditText descriptionEndroit = (EditText) dialog.findViewById(R.id.dialogEditTextDescription);

        nomEndroit.setText(m_nom);
        descriptionEndroit.setText(m_description);

        Button ok = (Button) dialog.findViewById(R.id.dialogButtonOk);
        Button annuler = (Button) dialog.findViewById(R.id.dialogButtonAnnuler);

        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!ValidationsMarqueur.ValiderMarqueur(v.getContext(), m_nom, m_description)) {
                    return;
                }

                // on enregistre dans deux variables le nouveau nom et description
                // et on affiche les nouvelles informations dans la zone d'information,
                // mais on ne touche pas au marqueur pour l'instant
                m_nom = nomEndroit.getText().toString();
                m_description = descriptionEndroit.getText().toString();
                m_textInformation1.setText(m_nom);
                m_textInformation2.setText(m_description);

                // on indique que le marqueur a été modifié
                m_marqueurEstModifie = true;

                dialog.cancel();
            }
        });

        annuler.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dialog.cancel();
            }
        });
    }

    /**
     * Régénère la map au besoin
     */
    @Override
    protected void onResume() {
        super.onResume();
        setUpMapIfNeeded();
    }

    /**
     * Sets up the map if it is possible to do so (i.e., the Google Play services APK is correctly
     * installed) and the map has not already been instantiated.. This will ensure that we only ever
     * call {@link #setUpMap()} once when {@link #m_map} is not null.
     * <p/>
     * If it isn't installed {@link SupportMapFragment} (and
     * {@link com.google.android.gms.maps.MapView MapView}) will show a prompt for the user to
     * install/update the Google Play services APK on their device.
     * <p/>
     * A user can return to this FragmentActivity after following the prompt and correctly
     * installing/updating/enabling the Google Play services. Since the FragmentActivity may not
     * have been completely destroyed during this process (it is likely that it would only be
     * stopped or paused), {@link #onCreate(Bundle)} may not be called again so we should call this
     * method in {@link #onResume()} to guarantee that it will be called.
     */
    private void setUpMapIfNeeded() {
        // Do a null check to confirm that we have not already instantiated the map.
        if (m_map == null) {
            // Try to obtain the map from the SupportMapFragment.
            m_map = ((SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map))
                    .getMap();
            // Check if we were successful in obtaining the map.
            if (m_map != null) {
                setUpMap();
            }
        }
    }

    /**
     * This is where we can add markers or lines, add listeners or move the camera.
     * <p/>
     * This should only be called once and when we are sure that {@link #m_map} is not null.
     */
    private void setUpMap() {
        ChargerMap();
        CreerListenerMarqueur();
        m_map.getUiSettings().setZoomControlsEnabled(true);
    }
}
