package raymondlongtintp3.example.com.tp3raymondlongtin.database;

import android.database.Cursor;
import android.database.CursorWrapper;

import java.util.UUID;


import com.google.android.gms.maps.model.LatLng;
import raymondlongtintp3.example.com.tp3raymondlongtin.Marqueur;
import raymondlongtintp3.example.com.tp3raymondlongtin.database.MarqueurDbSchema.MarqueurTable;


/**
 * Classe d'encapsulation de Cursor, ajoute des fonctionnalités (aucune pour le moment)
 * et donne accès à des méthodes utiles au traitement du curseur
 */
public class MarqueurCursorWrapper extends CursorWrapper {
    /**
     * Créée un "cursor wrapper"
     *
     * @param cursor le curseur à encapsuler
     */
    public MarqueurCursorWrapper(Cursor cursor) {
        super(cursor);  // appèle le constructeur de CursorWrapper
    }


    /**
     * Acesseur d'un élément dans la base de données, celui "pointé" par le curseur
     * @return  le marqueur pointé par le curseur (Marqueur)
     */
    public Marqueur getMarqueur() {
        // va chercher les informations sur les Marqueurs dans la base de données
        String uuidString = getString(getColumnIndex(MarqueurTable.Colonnes.ID));
        String nom = getString(getColumnIndex(MarqueurTable.Colonnes.NOM));
        String description = getString(getColumnIndex(MarqueurTable.Colonnes.DESCRIPTION));
        double latitude = getDouble(getColumnIndex(MarqueurTable.Colonnes.LATITUDE));
        double longitude = getDouble(getColumnIndex(MarqueurTable.Colonnes.LONGITUDE));

        // recréée l'élément à partir de son ID et ajoute les valeurs qui étaient dans la base de données
        return new Marqueur(UUID.fromString(uuidString), nom, description, new LatLng(latitude, longitude));
    }
} // class ElementCursorWrapper