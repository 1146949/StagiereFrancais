package raymondlongtintp3.example.com.tp3raymondlongtin.TestUnitaires;

import org.junit.Test;
import java.util.regex.Pattern;
import raymondlongtintp3.example.com.tp3raymondlongtin.ValidationsMarqueur;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

public class ValidationTester {

    @Test
    public void emailValidator_CorrectEmailSimple_ReturnsTrue() {
        assertTrue(ValidationsMarqueur.NonVide("LOL"));
    }
}