package raymondlongtintp3.example.com.tp3raymondlongtin;

import android.app.Application;
import android.test.ApplicationTestCase;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

import raymondlongtintp3.example.com.tp3raymondlongtin.TestInterfaces.MapsActivityTester;
import raymondlongtintp3.example.com.tp3raymondlongtin.TestUnitaires.ValidationTester;

@RunWith(Suite.class)
@Suite.SuiteClasses({
    MapsActivityTester.class,
    ValidationTester.class
})
public class TestComplet {

}