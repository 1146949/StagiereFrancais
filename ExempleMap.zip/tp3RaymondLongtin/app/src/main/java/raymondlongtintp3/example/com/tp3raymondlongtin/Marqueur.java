package raymondlongtintp3.example.com.tp3raymondlongtin;

import com.google.android.gms.maps.model.LatLng;

import java.util.UUID;

/**
 * Created by 1441874 on 2015-12-10.a
 */
public class Marqueur {

    /**
     * Creer un infoMarqueur avec un UUID aleatoire
     * @param p_id identifiant des informations du marqueur dans la BD
     * @param p_nom Nom du marqueur
     * @param p_description description du marqueur
     * @param p_position position de type LatLng contenant la longitude et la latitude du marqueur
     */
    public Marqueur(UUID p_id, String p_nom, String p_description, LatLng p_position)
    {
        Nom = p_nom;
        Description = p_description;
        Position = p_position;
        ID = p_id;
    }

    private String Nom;
    private String Description;
    private LatLng Position;
    private UUID ID;

    /**
     * Accesseur du nom, (peut n'avoir aucune valeur... attention)
     * @return nom du Marqueur
     */
    public String getNom() {
        return Nom;
    }

    /**
     * Accesseur de la description, (peut n'avoir aucune valeur... attention)
     * @return description du Marqueur
     */
    public String getDescription() {
        return Description;
    }

    /**
     * Accesseur de la postition, (peut n'avoir aucune valeur... attention)
     * @return position du Marqueur (LatLng)
     */
    public LatLng getPosition() {
        return Position;
    }

    /**
     * Accesseur de l'ID, (peut n'avoir aucune valeur... attention)
     * @return UUID du Marqueur
     */
    public UUID getID() {
        return ID;
    }
}
