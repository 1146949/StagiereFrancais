package raymondlongtintp3.example.com.tp3raymondlongtin;

import android.content.Context;
import android.widget.Toast;

import raymondlongtintp3.example.com.tp3raymondlongtin.R;
import raymondlongtintp3.example.com.tp3raymondlongtin.Validation;


/***
 * Classe de validation des marqueurs (leurs nom et description)
 */
class ValidationsMarqueur extends Validation {

    /**
     * Valide les informations d'un marqueur
     * @param p_contexte Pour savoir où afficher le toast
     * @param p_nomMarqueur nom du marqueur à valider
     * @param p_descriptionMarqueur description du marqueur à valider
     * @return true si le nom et la description sont valides
     */
    public static boolean ValiderMarqueur(Context p_contexte, String p_nomMarqueur, String p_descriptionMarqueur)
    {
        return ValiderNom(p_nomMarqueur, p_contexte) &&
                ValiderDescription(p_descriptionMarqueur, p_contexte);
    }

    /**
     * Verifie si le nom est vide
     * @param p_nom nom a valider
     * @param p_contexte contexte d'affichage du toast
     * @return true si le nom est valide
     */
    private static boolean ValiderNom(String p_nom, Context p_contexte)
    {
        if(Vide(p_nom)) {
            Toast.makeText(p_contexte, R.string.nomInvalide, Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    /***
     * Verifie si la description est vide
     * @param p_description description a valider
     * @param p_contexte contexte d'affichage du toast
     * @return true si le nom est valide
     */
    private static boolean ValiderDescription(String p_description, Context p_contexte)
    {
        if(Vide(p_description)) {
            Toast.makeText(p_contexte, R.string.descriptionInvalide, Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}
