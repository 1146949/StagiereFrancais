package raymondlongtintp3.example.com.tp3raymondlongtin;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Classe de validations sur les String et int
 */
class Validation {
    /**
     * Valide si la chaine est non-vide
     * @param p_texte texte à valider
     * @return vrai si p_texte n'est pas vide
     */
    public static boolean NonVide(String p_texte) {
        return 0 < p_texte.length();
    }

    /**
     * @param p_texte texte à valider
     * @param p_minimum longueur minimale que le texte doit avoir
     * @return vrai si p_texte a au minimum p_minimum caractères
     */
    public static boolean Minimum(String p_texte, int p_minimum) {
        return p_minimum <= p_texte.length();
    }

    /**
     * @param p_texte texte à valider
     * @param p_maximum longueur maximale que le texte doit avoir
     * @return vrai si p_texte a au maximum p_ maximum caractères
     */
    public static boolean Maximum(String p_texte, int p_maximum) {
        return p_texte.length() <= p_maximum;
    }

    /**
     * @param p_texte texte à valider
     * @param p_minimum longueur minimale que le texte doit avoir
     * @param p_maximum longueur maximale que le texte doit avoir
     * @return Retourne vrai si p_texte a au minimum p_minimum caractères et au maximum p_ maximum caractères
     */
    public static boolean Entre(String p_texte, int p_minimum, int p_maximum) {
        return Validation.Minimum(p_texte, p_minimum) && Validation.Maximum(p_texte, p_maximum);
    }

    /**
     * @param p_nb nombre à valider
     * @param p_minimum nombre minimal que le nombre à valider doit atteindre
     * @param p_maximum nombre maximal que le nombre à valider doit atteindre
     * @return Retourne vrai si p_nombre est entre p_minimum et p_maximum
     */
    public static boolean Entre(int p_nb, int p_minimum, int p_maximum) {
        return p_minimum <= p_nb && p_nb <= p_maximum;
    }

    /**
     * @param p_texte texte à valider
     * @param p_minimum nombre minimal de majuscules que le texte doit avoir
     * @return Retourne vrai si p_texte a au minimum p_minimum majuscules
     */
    public static boolean MinimumMajuscule(String p_texte, int p_minimum) {
        // Ceci fait la différence entre la longueur de la chaine avec et sans ses majuscules
        // donnant le nombre de celles-ci
        return (p_texte.length() - p_texte.replaceAll("[A-Z]", "").length()) >= p_minimum;
    }

    public static boolean DebuteParMajuscule(String p_texte) {
        Pattern p = Pattern.compile("^[A-Z].*$");
        Matcher m = p.matcher(p_texte);
        return p_texte.length() > 0 && m.matches();
    }

    /**
     * @param p_texte texte dont on veut valider le contenu
     * @return Retourne vrai si p_texte est vide
     */
    public static boolean Vide(String p_texte) {
        return  p_texte != null && p_texte.trim().length() == 0;
    }

    /**
     * @param p_texte texte à valider
     * @param p_minimum nombre minimal de chiffres que le texte doit avoir
     * @return Retourne vrai si p_texte a au minimum p_minimum chiffres
     */
    public static boolean MinimumChiffre(String p_texte, int p_minimum) {
        return (p_texte.length() - p_texte.replaceAll("[0-9]", "").length()) >= p_minimum;
    }
}